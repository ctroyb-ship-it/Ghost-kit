import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { C as randomLoadout, E as sanitizeCallsign, S as randomCallsign, T as sameLoadout, _ as SKINS, a as FRAMINGS, c as HAIR_COLORS, d as KITS, f as MASKS, g as PRESETS, h as POSES, i as EYE_COLORS, l as HEADS, m as PATTERNS, n as BOTTOMS, o as GENDERS, p as OPTICS, r as CLOTHES, s as HAIRS, t as BACKGROUNDS, u as HOUSE_LOADOUT, v as WEAPONS, x as parseForgeInput } from "./loadout-DW4Sv497.mjs";
import { i as Download, n as Trash2, r as Shuffle } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DSJoxpHJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var forgeStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("bc19d2a96977be80c25d8499bd4449b01ff2b9d89da344fea4ec0c51f2f64a5a"));
var forgeOperator = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("c0cf4dc143e6fa82b2a0d6fa95211f7117c02b9e55b8c69b5c44f7404771e649"));
var STORAGE_KEY = "ghost-kit-v1";
var HOUSE_SRC = "/samples/parade.jpg";
var MAX_PLATES = 6;
function loadSaved() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		const spec = parseForgeInput({
			...parsed.loadout ?? {},
			detail: typeof parsed.detail === "string" ? parsed.detail : ""
		});
		if (!spec) return null;
		const plates = Array.isArray(parsed.plates) ? parsed.plates.filter((plate) => {
			if (!plate || typeof plate !== "object") return false;
			const row = plate;
			return typeof row.id === "string" && typeof row.image === "string" && typeof row.callsign === "string" && parseForgeInput({
				...row.loadout ?? {},
				detail: ""
			}) !== null;
		}).slice(0, MAX_PLATES) : [];
		return {
			callsign: sanitizeCallsign(parsed.callsign || "HOLLOW") || "HOLLOW",
			detail: spec.detail,
			loadout: spec,
			activeId: typeof parsed.activeId === "string" ? parsed.activeId : null,
			plates
		};
	} catch {
		return null;
	}
}
function compress(dataUrl) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, 768 / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				reject(/* @__PURE__ */ new Error("no canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			resolve(canvas.toDataURL("image/jpeg", .82));
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("image"));
		img.src = dataUrl;
	});
}
function Chip({ pressed, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: "min-h-11 rounded-sm px-3 font-display text-lg tracking-wide transition-colors duration-150 " + (pressed ? "bg-paper text-ink" : "border border-line bg-subtle text-fg hover:border-muted"),
		children
	});
}
function Group({ index, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
			className: "font-display text-sm tracking-widest text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mr-2 text-faint",
				children: index
			}), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children
		})]
	});
}
function Studio() {
	const [callsign, setCallsign] = (0, import_react.useState)("HOLLOW");
	const [detail, setDetail] = (0, import_react.useState)("");
	const [loadout, setLoadout] = (0, import_react.useState)(HOUSE_LOADOUT);
	const [plates, setPlates] = (0, import_react.useState)([]);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(null);
	const [forging, setForging] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = loadSaved();
		if (saved) {
			setCallsign(saved.callsign);
			setDetail(saved.detail);
			setLoadout(saved.loadout);
			setPlates(saved.plates);
			setActiveId(saved.activeId);
		}
		setHydrated(true);
		forgeStatus().then((status) => setReady(status.ready)).catch(() => setReady(false));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const payload = {
			callsign,
			detail,
			loadout,
			activeId,
			plates
		};
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
		} catch {
			const slim = {
				...payload,
				plates: payload.plates.slice(0, 2)
			};
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
				setPlates(slim.plates);
			} catch {}
		}
	}, [
		hydrated,
		callsign,
		detail,
		loadout,
		activeId,
		plates
	]);
	(0, import_react.useEffect)(() => {
		if (!forging) {
			setElapsed(0);
			return;
		}
		const timer = window.setInterval(() => setElapsed((value) => value + 1), 1e3);
		return () => window.clearInterval(timer);
	}, [forging]);
	const active = plates.find((plate) => plate.id === activeId) ?? null;
	const stageSrc = active?.image ?? HOUSE_SRC;
	const stageCallsign = active?.callsign ?? "PARADE";
	const stageFraming = active?.loadout.framing ?? "parade";
	const stageBg = active?.loadout.background ?? "green";
	const dirty = active ? !sameLoadout(loadout, active.loadout) || callsign !== active.callsign : !sameLoadout(loadout, HOUSE_LOADOUT);
	function patch(partial) {
		setLoadout((current) => ({
			...current,
			...partial
		}));
	}
	function toggleKit(id) {
		setLoadout((current) => {
			const has = current.kit.includes(id);
			return {
				...current,
				kit: has ? current.kit.filter((item) => item !== id) : [...current.kit, id]
			};
		});
	}
	function applyPreset(next) {
		setLoadout((current) => ({
			...next,
			gender: current.gender,
			hair: current.hair ?? "covered",
			background: current.background ?? "green",
			clothing: current.clothing ?? "uniform",
			hairColor: current.hairColor ?? "brown",
			eyeColor: current.eyeColor ?? "brown",
			skin: current.skin ?? "fair",
			head: current.head ?? "helmet",
			bottoms: current.bottoms ?? "shorts",
			pose: current.pose ?? "stand"
		}));
		setError(null);
	}
	function shuffle() {
		setLoadout(randomLoadout());
		setCallsign((current) => randomCallsign(current));
		setError(null);
	}
	function selectPlate(plate) {
		setActiveId(plate.id);
		setLoadout(plate.loadout);
		setCallsign(plate.callsign);
		setError(null);
	}
	function removePlate(id) {
		setPlates((current) => current.filter((plate) => plate.id !== id));
		setActiveId((current) => current === id ? null : current);
	}
	async function forge() {
		if (forging || ready === false) return;
		setForging(true);
		setError(null);
		try {
			const result = await forgeOperator({ data: {
				...loadout,
				detail
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			let image = result.image;
			try {
				image = await compress(result.image);
			} catch {
				image = result.image;
			}
			const plate = {
				id: crypto.randomUUID(),
				callsign: callsign || "HOLLOW",
				image,
				loadout: {
					...loadout,
					hair: result.hair
				},
				createdAt: Date.now()
			};
			setPlates((current) => [plate, ...current].slice(0, MAX_PLATES));
			setActiveId(plate.id);
		} catch {
			setError("The forge didn’t answer. Try again.");
		} finally {
			setForging(false);
		}
	}
	const fileName = `ghost-kit-${(active?.callsign || callsign || "operator").toLowerCase().replace(/[^a-z0-9]+/g, "-")}.jpg`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-bg pb-16 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm tracking-widest text-muted",
						children: "OPERATOR FORGE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl leading-none font-semibold tracking-tight",
						children: "Ghost Kit"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: shuffle,
						disabled: forging,
						className: "inline-flex min-h-11 items-center gap-2 rounded-sm border border-line bg-elevated px-3 font-display text-lg tracking-wide text-fg transition-colors duration-150 hover:border-muted disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Shuffle"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: forge,
						disabled: forging || ready === false,
						className: "inline-flex min-h-11 min-w-28 items-center justify-center rounded-sm bg-paper px-4 font-display text-lg tracking-wide text-ink transition-opacity duration-150 hover:opacity-90 disabled:opacity-50",
						children: forging ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								"Forging ",
								elapsed,
								"s"
							]
						}) : "Forge"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pt-4 lg:grid-cols-[minmax(0,1fr)_22rem] lg:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative mx-auto overflow-hidden rounded-xl stage-bg-${stageBg} ${forging ? "forging-stage" : ""} stage-${stageFraming}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: stageSrc,
							alt: `${stageCallsign} operator`,
							className: "absolute inset-0 h-full w-full object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-sm bg-ink/80 px-2 py-1 font-display text-sm tracking-widest text-paper",
								children: active ? "PLATE" : "HOUSE"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-sm bg-ink/80 px-2 py-1 font-display text-lg tracking-widest text-paper",
								children: stageCallsign
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: stageSrc,
								download: fileName,
								className: "inline-flex min-h-11 items-center gap-2 rounded-sm bg-ink/80 px-3 font-display text-lg tracking-wide text-paper",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Save"]
							}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => removePlate(active.id),
								className: "inline-flex min-h-11 items-center gap-2 rounded-sm bg-ink/80 px-3 font-display text-lg tracking-wide text-paper",
								"aria-label": `Delete ${active.callsign}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Drop"]
							}) : null]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-wide",
							children: "Plates"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-sm tracking-widest text-faint tabular-nums",
							children: [
								plates.length,
								"/",
								MAX_PLATES
							]
						})]
					}), plates.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "Forged operators stay on this device. The stage is the house parade plate until you cut your own."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: plates.map((plate) => {
							const selected = plate.id === activeId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => selectPlate(plate),
									"aria-pressed": selected,
									className: "block w-16 overflow-hidden rounded-sm border bg-stage " + (selected ? "border-paper" : "border-line"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: plate.image,
										alt: "",
										className: "aspect-[3/4] w-full object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate bg-ink px-1 py-1 text-center font-display text-xs tracking-wide text-paper",
										children: plate.callsign
									})]
								})
							}, plate.id);
						})
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4 rounded-xl border border-line bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-sm tracking-widest text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 text-faint",
								children: "17"
							}), "PRESETS"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => applyPreset(preset.loadout),
								className: "min-h-11 rounded-sm border border-line bg-subtle px-2 py-2 text-left transition-colors duration-150 hover:border-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-lg leading-none tracking-wide",
									children: preset.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs text-pretty text-muted",
									children: preset.note
								})]
							}, preset.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm tracking-widest text-muted",
							children: "CALLSIGN"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: callsign,
								maxLength: 16,
								autoCapitalize: "characters",
								onChange: (event) => setCallsign(sanitizeCallsign(event.target.value)),
								className: "h-11 min-w-0 flex-1 rounded-sm border border-line bg-subtle px-3 font-display text-xl tracking-widest text-fg uppercase"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "New callsign",
								onClick: () => setCallsign((current) => randomCallsign(current)),
								className: "inline-flex size-11 items-center justify-center rounded-sm border border-line bg-subtle text-fg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {
									className: "size-4",
									"aria-hidden": "true"
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "01",
						label: "GENDER",
						children: GENDERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.gender ?? "male") === item.id,
							onClick: () => patch({ gender: item.id }),
							children: item.label
						}, item.id))
					}),
					(loadout.gender ?? "male") === "female" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "02",
						label: "CLOTHES",
						children: CLOTHES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.clothing ?? "uniform") === item.id,
							onClick: () => patch({ clothing: item.id }),
							children: item.label
						}, item.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "03",
						label: "BOTTOMS",
						children: BOTTOMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.bottoms ?? "shorts") === item.id,
							onClick: () => patch({ bottoms: item.id }),
							children: item.label
						}, item.id))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "04",
						label: "FRAMING",
						children: FRAMINGS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.framing === item.id,
							onClick: () => patch({ framing: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "05",
						label: "POSE",
						children: POSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.pose ?? "stand") === item.id,
							onClick: () => patch({ pose: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "06",
						label: "FACE",
						children: MASKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.mask === item.id,
							onClick: () => patch({ mask: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "07",
						label: "HAIR",
						children: HAIRS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.hair ?? "covered") === item.id,
							onClick: () => patch({ hair: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "08",
						label: "COLOR",
						children: HAIR_COLORS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.hairColor ?? "brown") === item.id,
							onClick: () => patch({ hairColor: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "09",
						label: "EYES",
						children: EYE_COLORS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.eyeColor ?? "brown") === item.id,
							onClick: () => patch({ eyeColor: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "10",
						label: "SKIN",
						children: SKINS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.skin ?? "fair") === item.id,
							onClick: () => patch({ skin: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "11",
						label: "HEAD",
						children: HEADS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.head ?? "helmet") === item.id,
							onClick: () => patch({ head: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "12",
						label: "PATTERN",
						children: PATTERNS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.pattern === item.id,
							onClick: () => patch({ pattern: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "13",
						label: "OPTIC",
						children: OPTICS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.optic === item.id,
							onClick: () => patch({ optic: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "14",
						label: "WEAPON",
						children: WEAPONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.weapon === item.id,
							onClick: () => patch({ weapon: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "15",
						label: "BACKDROP",
						children: BACKGROUNDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: (loadout.background ?? "green") === item.id,
							onClick: () => patch({ background: item.id }),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						index: "16",
						label: "KIT",
						children: KITS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: loadout.kit.includes(item.id),
							onClick: () => toggleKit(item.id),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-sm tracking-widest text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 text-faint",
								children: "11"
							}), "NOTE"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: detail,
							maxLength: 140,
							rows: 2,
							placeholder: "Left-handed grip. Extra mag pouches.",
							onChange: (event) => setDetail(event.target.value.slice(0, 140)),
							className: "w-full resize-none rounded-sm border border-line bg-subtle px-3 py-2 text-sm text-fg placeholder:text-faint"
						})]
					}),
					dirty && !forging ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Kit changed. Forge to cut a new plate."
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						role: "alert",
						children: error
					}) : null,
					ready === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Image forging isn’t available right now."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-faint",
						children: "One image each time you forge. Plates stay on this device."
					})
				]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
