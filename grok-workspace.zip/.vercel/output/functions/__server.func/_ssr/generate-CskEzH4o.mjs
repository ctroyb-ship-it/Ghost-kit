import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { b as buildPrompt, w as resolveHair, x as parseForgeInput, y as aspectFor } from "./loadout-DW4Sv497.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/generate-CskEzH4o.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var COOLDOWN_MS = 4e3;
var lastStarted = 0;
function failure(status, raw) {
	let msg = "";
	try {
		const parsed = JSON.parse(raw);
		if (typeof parsed.error === "string") msg = parsed.error;
		else if (parsed.error && typeof parsed.error.message === "string") msg = parsed.error.message;
	} catch {
		msg = "";
	}
	if (/policy|moderat|safety|violate/i.test(msg)) return "That kit was refused. Change the note and forge again.";
	if (status === 429) return "The forge is busy. Wait a moment and try again.";
	if (status === 401 || status === 403) return "Image forging isn’t available right now.";
	return "The forge didn’t answer. Try again.";
}
async function toDataUrl(item, apiKey) {
	if (item.b64_json) return `data:${item.mime_type || "image/jpeg"};base64,${item.b64_json}`;
	if (!item.url) return null;
	const image = await fetch(item.url, {
		headers: { Authorization: `Bearer ${apiKey}` },
		signal: AbortSignal.timeout(3e4)
	});
	if (!image.ok) return null;
	return `data:${image.headers.get("content-type") || "image/jpeg"};base64,${Buffer.from(await image.arrayBuffer()).toString("base64")}`;
}
var forgeStatus_createServerFn_handler = createServerRpc({
	id: "bc19d2a96977be80c25d8499bd4449b01ff2b9d89da344fea4ec0c51f2f64a5a",
	name: "forgeStatus",
	filename: "src/lib/forge/generate.ts"
}, (opts) => forgeStatus.__executeServer(opts));
var forgeStatus = createServerFn({ method: "GET" }).handler(forgeStatus_createServerFn_handler, async () => {
	return { ready: Boolean(process.env.XAI_API_KEY) };
});
var forgeOperator_createServerFn_handler = createServerRpc({
	id: "c0cf4dc143e6fa82b2a0d6fa95211f7117c02b9e55b8c69b5c44f7404771e649",
	name: "forgeOperator",
	filename: "src/lib/forge/generate.ts"
}, (opts) => forgeOperator.__executeServer(opts));
var forgeOperator = createServerFn({ method: "POST" }).validator((input) => input).handler(forgeOperator_createServerFn_handler, async ({ data }) => {
	const spec = parseForgeInput(data);
	if (!spec) return {
		ok: false,
		error: "That kit isn’t one of the plates."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Image forging isn’t available right now."
	};
	const now = Date.now();
	if (now - lastStarted < COOLDOWN_MS) return {
		ok: false,
		error: "Give the forge a second."
	};
	lastStarted = now;
	const { refData } = await import("./ref-data-BrpaHyKQ.mjs");
	const framing = spec.framing;
	const reference = refData[framing];
	const hair = resolveHair(spec.hair);
	let response;
	try {
		response = await fetch("https://api.x.ai/v1/images/edits", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(7e4),
			body: JSON.stringify({
				model: "grok-imagine-image-2.0",
				prompt: buildPrompt(spec, hair),
				image: {
					url: reference,
					type: "image_url"
				},
				response_format: "b64_json",
				aspect_ratio: aspectFor(framing),
				resolution: "1k",
				quality: "medium"
			})
		});
	} catch {
		return {
			ok: false,
			error: "The forge didn’t answer. Try again."
		};
	}
	if (!response.ok) {
		const raw = await response.text();
		return {
			ok: false,
			error: failure(response.status, raw)
		};
	}
	const item = (await response.json()).data?.[0];
	if (!item) return {
		ok: false,
		error: "The forge came back empty. Try again."
	};
	try {
		const image = await toDataUrl(item, apiKey);
		if (!image) return {
			ok: false,
			error: "The forge came back empty. Try again."
		};
		return {
			ok: true,
			image,
			hair
		};
	} catch {
		return {
			ok: false,
			error: "The forge didn’t answer. Try again."
		};
	}
});
//#endregion
export { forgeOperator_createServerFn_handler, forgeStatus_createServerFn_handler };
