import { useEffect, useState, type ReactNode } from "react";
import { Download, Shuffle, Trash2 } from "lucide-react";
import { forgeOperator, forgeStatus } from "@/lib/forge/generate";
import {
  BACKGROUNDS,
  BOTTOMS,
  CLOTHES,
  EYE_COLORS,
  FRAMINGS,
  GENDERS,
  HAIR_COLORS,
  HAIRS,
  HEADS,
  SKINS,
  HOUSE_LOADOUT,
  KITS,
  MASKS,
  OPTICS,
  PATTERNS,
  POSES,
  PRESETS,
  WEAPONS,
  parseForgeInput,
  randomCallsign,
  randomLoadout,
  sameLoadout,
  sanitizeCallsign,
  type Framing,
  type Loadout,
} from "@/lib/forge/loadout";

const STORAGE_KEY = "ghost-kit-v1";
const HOUSE_SRC = "/samples/parade.jpg";
const MAX_PLATES = 6;

type Plate = {
  id: string;
  callsign: string;
  image: string;
  loadout: Loadout;
  createdAt: number;
};

type Saved = {
  callsign: string;
  detail: string;
  loadout: Loadout;
  activeId: string | null;
  plates: Plate[];
};

function loadSaved(): Saved | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Saved>;
    const spec = parseForgeInput({
      ...(parsed.loadout ?? {}),
      detail: typeof parsed.detail === "string" ? parsed.detail : "",
    });
    if (!spec) return null;
    const plates = Array.isArray(parsed.plates)
      ? parsed.plates.filter((plate): plate is Plate => {
          if (!plate || typeof plate !== "object") return false;
          const row = plate as Plate;
          return (
            typeof row.id === "string" &&
            typeof row.image === "string" &&
            typeof row.callsign === "string" &&
            parseForgeInput({ ...(row.loadout ?? {}), detail: "" }) !== null
          );
        }).slice(0, MAX_PLATES)
      : [];
    return {
      callsign: sanitizeCallsign(parsed.callsign || "HOLLOW") || "HOLLOW",
      detail: spec.detail,
      loadout: spec,
      activeId: typeof parsed.activeId === "string" ? parsed.activeId : null,
      plates,
    };
  } catch {
    return null;
  }
}

function compress(dataUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const max = 768;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("no canvas"));
        return;
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => reject(new Error("image"));
    img.src = dataUrl;
  });
}

function Chip({
  pressed,
  children,
  onClick,
}: {
  pressed: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={
        "min-h-11 rounded-sm px-3 font-display text-lg tracking-wide transition-colors duration-150 " +
        (pressed
          ? "bg-paper text-ink"
          : "border border-line bg-subtle text-fg hover:border-muted")
      }
    >
      {children}
    </button>
  );
}

function Group({
  index,
  label,
  children,
}: {
  index: string;
  label: string;
  children: ReactNode;
}) {
  return (
    <fieldset className="space-y-2">
      <legend className="font-display text-sm tracking-widest text-muted">
        <span className="mr-2 text-faint">{index}</span>
        {label}
      </legend>
      <div className="flex flex-wrap gap-2">{children}</div>
    </fieldset>
  );
}

export function Studio() {
  const [callsign, setCallsign] = useState("HOLLOW");
  const [detail, setDetail] = useState("");
  const [loadout, setLoadout] = useState<Loadout>(HOUSE_LOADOUT);
  const [plates, setPlates] = useState<Plate[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [ready, setReady] = useState<boolean | null>(null);
  const [forging, setForging] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const saved = loadSaved();
    if (saved) {
      setCallsign(saved.callsign);
      setDetail(saved.detail);
      setLoadout(saved.loadout);
      setPlates(saved.plates);
      setActiveId(saved.activeId);
    }
    setHydrated(true);
    forgeStatus()
      .then((status) => setReady(status.ready))
      .catch(() => setReady(false));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const payload: Saved = { callsign, detail, loadout, activeId, plates };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      const slim = { ...payload, plates: payload.plates.slice(0, 2) };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
        setPlates(slim.plates);
      } catch {
        /* session only */
      }
    }
  }, [hydrated, callsign, detail, loadout, activeId, plates]);

  useEffect(() => {
    if (!forging) {
      setElapsed(0);
      return;
    }
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [forging]);

  const active = plates.find((plate) => plate.id === activeId) ?? null;
  const stageSrc = active?.image ?? HOUSE_SRC;
  const stageCallsign = active?.callsign ?? "PARADE";
  const stageFraming: Framing = active?.loadout.framing ?? "parade";
  const stageBg = active?.loadout.background ?? "green";
  const dirty = active ? !sameLoadout(loadout, active.loadout) || callsign !== active.callsign : !sameLoadout(loadout, HOUSE_LOADOUT);

  function patch(partial: Partial<Loadout>) {
    setLoadout((current) => ({ ...current, ...partial }));
  }

  function toggleKit(id: Loadout["kit"][number]) {
    setLoadout((current) => {
      const has = current.kit.includes(id);
      return {
        ...current,
        kit: has ? current.kit.filter((item) => item !== id) : [...current.kit, id],
      };
    });
  }

  function applyPreset(next: Loadout) {
    setLoadout((current) => ({
      ...next,
      gender: current.gender,
      hair: current.hair ?? "covered",
      background: current.background ?? "green",
      clothing: current.clothing ?? "uniform",
      hairColor: current.hairColor ?? "brown",
      eyeColor: current.eyeColor ?? "brown",
      skin: current.skin ?? "fair",
      head: current.head ?? "helmet",
      bottoms: current.bottoms ?? "shorts",
      pose: current.pose ?? "stand",
    }));
    setError(null);
  }

  function shuffle() {
    setLoadout(randomLoadout());
    setCallsign((current) => randomCallsign(current));
    setError(null);
  }

  function selectPlate(plate: Plate) {
    setActiveId(plate.id);
    setLoadout(plate.loadout);
    setCallsign(plate.callsign);
    setError(null);
  }

  function removePlate(id: string) {
    setPlates((current) => current.filter((plate) => plate.id !== id));
    setActiveId((current) => (current === id ? null : current));
  }

  async function forge() {
    if (forging || ready === false) return;
    setForging(true);
    setError(null);
    try {
      const result = await forgeOperator({
        data: { ...loadout, detail },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      let image = result.image;
      try {
        image = await compress(result.image);
      } catch {
        image = result.image;
      }
      const plate: Plate = {
        id: crypto.randomUUID(),
        callsign: callsign || "HOLLOW",
        image,
        loadout: { ...loadout, hair: result.hair },
        createdAt: Date.now(),
      };
      setPlates((current) => [plate, ...current].slice(0, MAX_PLATES));
      setActiveId(plate.id);
    } catch {
      setError("The forge didn’t answer. Try again.");
    } finally {
      setForging(false);
    }
  }

  const fileName = `ghost-kit-${(active?.callsign || callsign || "operator")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")}.jpg`;

  return (
    <main className="min-h-dvh bg-bg pb-16 text-fg">
      <header className="sticky top-0 z-20 border-b border-line bg-bg">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <p className="font-display text-sm tracking-widest text-muted">OPERATOR FORGE</p>
            <h1 className="font-display text-3xl leading-none font-semibold tracking-tight">
              Ghost Kit
            </h1>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={shuffle}
              disabled={forging}
              className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-line bg-elevated px-3 font-display text-lg tracking-wide text-fg transition-colors duration-150 hover:border-muted disabled:opacity-50"
            >
              <Shuffle className="size-4" aria-hidden="true" />
              Shuffle
            </button>
            <button
              type="button"
              onClick={forge}
              disabled={forging || ready === false}
              className="inline-flex min-h-11 min-w-28 items-center justify-center rounded-sm bg-paper px-4 font-display text-lg tracking-wide text-ink transition-opacity duration-150 hover:opacity-90 disabled:opacity-50"
            >
              {forging ? (
                <span className="tabular-nums">Forging {elapsed}s</span>
              ) : (
                "Forge"
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-4 px-4 pt-4 lg:grid-cols-[minmax(0,1fr)_22rem] lg:items-start">
        <section className="space-y-4">
          <div
            className={`relative mx-auto overflow-hidden rounded-xl stage-bg-${stageBg} ${
              forging ? "forging-stage" : ""
            } stage-${stageFraming}`}
          >
            <img
              src={stageSrc}
              alt={`${stageCallsign} operator`}
              className="absolute inset-0 h-full w-full object-contain"
            />
            <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
              <span className="rounded-sm bg-ink/80 px-2 py-1 font-display text-sm tracking-widest text-paper">
                {active ? "PLATE" : "HOUSE"}
              </span>
              <span className="rounded-sm bg-ink/80 px-2 py-1 font-display text-lg tracking-widest text-paper">
                {stageCallsign}
              </span>
            </div>
            <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 p-3">
              <a
                href={stageSrc}
                download={fileName}
                className="inline-flex min-h-11 items-center gap-2 rounded-sm bg-ink/80 px-3 font-display text-lg tracking-wide text-paper"
              >
                <Download className="size-4" aria-hidden="true" />
                Save
              </a>
              {active ? (
                <button
                  type="button"
                  onClick={() => removePlate(active.id)}
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm bg-ink/80 px-3 font-display text-lg tracking-wide text-paper"
                  aria-label={`Delete ${active.callsign}`}
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                  Drop
                </button>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="font-display text-xl tracking-wide">Plates</h2>
              <p className="font-display text-sm tracking-widest text-faint tabular-nums">
                {plates.length}/{MAX_PLATES}
              </p>
            </div>
            {plates.length === 0 ? (
              <p className="text-sm text-pretty text-muted">
                Forged operators stay on this device. The stage is the house parade plate until you cut your own.
              </p>
            ) : (
              <ul className="flex gap-2 overflow-x-auto pb-1">
                {plates.map((plate) => {
                  const selected = plate.id === activeId;
                  return (
                    <li key={plate.id} className="shrink-0">
                      <button
                        type="button"
                        onClick={() => selectPlate(plate)}
                        aria-pressed={selected}
                        className={
                          "block w-16 overflow-hidden rounded-sm border bg-stage " +
                          (selected ? "border-paper" : "border-line")
                        }
                      >
                        <img
                          src={plate.image}
                          alt=""
                          className="aspect-[3/4] w-full object-cover"
                        />
                        <span className="block truncate bg-ink px-1 py-1 text-center font-display text-xs tracking-wide text-paper">
                          {plate.callsign}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-line bg-elevated p-4">
          <div className="space-y-2">
            <p className="font-display text-sm tracking-widest text-muted">
              <span className="mr-2 text-faint">17</span>
              PRESETS
            </p>
            <div className="grid grid-cols-3 gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => applyPreset(preset.loadout)}
                  className="min-h-11 rounded-sm border border-line bg-subtle px-2 py-2 text-left transition-colors duration-150 hover:border-muted"
                >
                  <span className="block font-display text-lg leading-none tracking-wide">
                    {preset.label}
                  </span>
                  <span className="mt-1 block text-xs text-pretty text-muted">{preset.note}</span>
                </button>
              ))}
            </div>
          </div>

          <label className="block space-y-2">
            <span className="font-display text-sm tracking-widest text-muted">CALLSIGN</span>
            <span className="flex gap-2">
              <input
                value={callsign}
                maxLength={16}
                autoCapitalize="characters"
                onChange={(event) => setCallsign(sanitizeCallsign(event.target.value))}
                className="h-11 min-w-0 flex-1 rounded-sm border border-line bg-subtle px-3 font-display text-xl tracking-widest text-fg uppercase"
              />
              <button
                type="button"
                aria-label="New callsign"
                onClick={() => setCallsign((current) => randomCallsign(current))}
                className="inline-flex size-11 items-center justify-center rounded-sm border border-line bg-subtle text-fg"
              >
                <Shuffle className="size-4" aria-hidden="true" />
              </button>
            </span>
          </label>

          <Group index="01" label="GENDER">
            {GENDERS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.gender ?? "male") === item.id}
                onClick={() => patch({ gender: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          {(loadout.gender ?? "male") === "female" ? (
            <>
            <Group index="02" label="CLOTHES">
              {CLOTHES.map((item) => (
                <Chip
                  key={item.id}
                  pressed={(loadout.clothing ?? "uniform") === item.id}
                  onClick={() => patch({ clothing: item.id })}
                >
                  {item.label}
                </Chip>
              ))}
            </Group>
            <Group index="03" label="BOTTOMS">
              {BOTTOMS.map((item) => (
                <Chip
                  key={item.id}
                  pressed={(loadout.bottoms ?? "shorts") === item.id}
                  onClick={() => patch({ bottoms: item.id })}
                >
                  {item.label}
                </Chip>
              ))}
            </Group>
            </>
          ) : null}

          <Group index="04" label="FRAMING">
            {FRAMINGS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.framing === item.id}
                onClick={() => patch({ framing: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="05" label="POSE">
            {POSES.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.pose ?? "stand") === item.id}
                onClick={() => patch({ pose: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="06" label="FACE">
            {MASKS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.mask === item.id}
                onClick={() => patch({ mask: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="07" label="HAIR">
            {HAIRS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.hair ?? "covered") === item.id}
                onClick={() => patch({ hair: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="08" label="COLOR">
            {HAIR_COLORS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.hairColor ?? "brown") === item.id}
                onClick={() => patch({ hairColor: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="09" label="EYES">
            {EYE_COLORS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.eyeColor ?? "brown") === item.id}
                onClick={() => patch({ eyeColor: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="10" label="SKIN">
            {SKINS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.skin ?? "fair") === item.id}
                onClick={() => patch({ skin: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="11" label="HEAD">
            {HEADS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.head ?? "helmet") === item.id}
                onClick={() => patch({ head: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="12" label="PATTERN">
            {PATTERNS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.pattern === item.id}
                onClick={() => patch({ pattern: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="13" label="OPTIC">
            {OPTICS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.optic === item.id}
                onClick={() => patch({ optic: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="14" label="WEAPON">
            {WEAPONS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.weapon === item.id}
                onClick={() => patch({ weapon: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="15" label="BACKDROP">
            {BACKGROUNDS.map((item) => (
              <Chip
                key={item.id}
                pressed={(loadout.background ?? "green") === item.id}
                onClick={() => patch({ background: item.id })}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <Group index="16" label="KIT">
            {KITS.map((item) => (
              <Chip
                key={item.id}
                pressed={loadout.kit.includes(item.id)}
                onClick={() => toggleKit(item.id)}
              >
                {item.label}
              </Chip>
            ))}
          </Group>

          <label className="block space-y-2">
            <span className="font-display text-sm tracking-widest text-muted">
              <span className="mr-2 text-faint">11</span>
              NOTE
            </span>
            <textarea
              value={detail}
              maxLength={140}
              rows={2}
              placeholder="Left-handed grip. Extra mag pouches."
              onChange={(event) => setDetail(event.target.value.slice(0, 140))}
              className="w-full resize-none rounded-sm border border-line bg-subtle px-3 py-2 text-sm text-fg placeholder:text-faint"
            />
          </label>

          {dirty && !forging ? (
            <p className="text-sm text-muted">Kit changed. Forge to cut a new plate.</p>
          ) : null}
          {error ? (
            <p className="text-sm text-fg" role="alert">
              {error}
            </p>
          ) : null}
          {ready === false ? (
            <p className="text-sm text-muted">Image forging isn’t available right now.</p>
          ) : (
            <p className="text-sm text-faint">One image each time you forge. Plates stay on this device.</p>
          )}
        </section>
      </div>
    </main>
  );
}
