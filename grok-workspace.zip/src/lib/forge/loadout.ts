export const GENDERS = [
  { id: "male", label: "Male" },
  { id: "female", label: "Female" },
] as const;

export const FRAMINGS = [
  { id: "parade", label: "Parade" },
  { id: "bust", label: "Portrait" },
  { id: "contact", label: "Contact" },
] as const;

export const POSES = [
  { id: "stand", label: "Stand" },
  { id: "prone", label: "Prone" },
  { id: "crouch", label: "Crouch" },
  { id: "ready", label: "Ready" },
  { id: "squat", label: "Side squat" },
] as const;

export const MASKS = [
  { id: "drip", label: "Drip skull" },
  { id: "angry", label: "Angry" },
  { id: "cracked", label: "Cracked" },
  { id: "visor", label: "Visor" },
  { id: "ghost", label: "Ghost" },
  { id: "balaclava", label: "Balaclava" },
  { id: "wrap", label: "Face wrap" },
  { id: "respirator", label: "Respirator" },
  { id: "half", label: "Half skull" },
  { id: "bare", label: "Bare" },
] as const;

export const HAIR_COLORS = [
  { id: "black", label: "Black" },
  { id: "brown", label: "Brown" },
  { id: "blonde", label: "Blonde" },
  { id: "red", label: "Red" },
  { id: "pink", label: "Pink" },
  { id: "white", label: "White" },
] as const;

export const EYE_COLORS = [
  { id: "brown", label: "Brown" },
  { id: "blue", label: "Blue" },
  { id: "green", label: "Green" },
  { id: "gray", label: "Gray" },
  { id: "hazel", label: "Hazel" },
] as const;

export const SKINS = [
  { id: "fair", label: "Fair" },
  { id: "tan", label: "Tan" },
  { id: "olive", label: "Olive" },
  { id: "brown", label: "Brown" },
  { id: "deep", label: "Deep" },
] as const;

export const HEADS = [
  { id: "helmet", label: "Helmet" },
  { id: "boonie", label: "Boonie" },
  { id: "cap", label: "Cap" },
  { id: "beanie", label: "Beanie" },
  { id: "headset", label: "Headset" },
  { id: "band", label: "Headband" },
] as const;

export const BOTTOMS = [
  { id: "shorts", label: "Shorts" },
  { id: "shorter", label: "Short shorts" },
  { id: "highcut", label: "High-cut" },
  { id: "camocut", label: "Camo high-cut" },
  { id: "highleg", label: "High-leg" },
  { id: "pants", label: "Pants" },
] as const;

export const HAIRS = [
  { id: "covered", label: "Covered" },
  { id: "pony", label: "Ponytail" },
  { id: "bun", label: "Bun" },
  { id: "loose", label: "Loose" },
  { id: "braid", label: "Braid" },
  { id: "crop", label: "Crop" },
  { id: "random", label: "Random" },
] as const;

export const PATTERNS = [
  { id: "multicam", label: "Multicam" },
  { id: "woodland", label: "Woodland" },
  { id: "desert", label: "Desert" },
  { id: "ranger", label: "Ranger" },
  { id: "black", label: "Black" },
  { id: "winter", label: "Winter" },
] as const;

export const OPTICS = [
  { id: "dual-up", label: "Tubes up" },
  { id: "dual-down", label: "Tubes down" },
  { id: "quad", label: "Quad tubes" },
  { id: "bare", label: "No tubes" },
] as const;

export const WEAPONS = [
  { id: "carbine-ready", label: "Carbine ready" },
  { id: "carbine-aim", label: "Carbine aim" },
  { id: "suppressed", label: "Suppressed" },
  { id: "marksman", label: "Marksman" },
  { id: "sniper", label: "Sniper" },
  { id: "smg", label: "SMG" },
  { id: "mg", label: "Machine gun" },
  { id: "shotgun", label: "Shotgun" },
  { id: "bow", label: "Bow" },
  { id: "sidearm", label: "Pistol" },
  { id: "blade", label: "Blade" },
  { id: "hands", label: "Hands free" },
] as const;

export const BACKGROUNDS = [
  { id: "green", label: "Green" },
  { id: "forest", label: "Forest" },
  { id: "desert", label: "Desert" },
  { id: "night", label: "Night" },
  { id: "urban", label: "Urban" },
  { id: "snow", label: "Snow" },
  { id: "hangar", label: "Hangar" },
  { id: "dusk", label: "Dusk" },
] as const;

export const CLOTHES = [
  { id: "uniform", label: "Uniform" },
  { id: "tank", label: "Tank" },
  { id: "crop", label: "Crop" },
  { id: "tee", label: "Tee" },
  { id: "rig", label: "Rig" },
  { id: "openrig", label: "Open rig" },
  { id: "plate", label: "Plate + tank" },
  { id: "sport", label: "Sports bra" },
  { id: "sportcamo", label: "Camo sport" },
  { id: "croptop", label: "Crop + plate" },
  { id: "camotank", label: "Camo tank" },
  { id: "open", label: "No shirt" },
] as const;

export const KITS = [
  { id: "knees", label: "Knee pads" },
  { id: "radio", label: "Radio" },
  { id: "holster", label: "Holster" },
  { id: "pack", label: "Pack" },
  { id: "gloves", label: "Gloves" },
  { id: "smoke", label: "Smoke" },
] as const;

export type Gender = (typeof GENDERS)[number]["id"];
export type Framing = (typeof FRAMINGS)[number]["id"];
export type Pose = (typeof POSES)[number]["id"];
export type Mask = (typeof MASKS)[number]["id"];
export type Hair = (typeof HAIRS)[number]["id"];
export type HairColor = (typeof HAIR_COLORS)[number]["id"];
export type EyeColor = (typeof EYE_COLORS)[number]["id"];
export type Skin = (typeof SKINS)[number]["id"];
export type Head = (typeof HEADS)[number]["id"];
export type Bottoms = (typeof BOTTOMS)[number]["id"];
export type Pattern = (typeof PATTERNS)[number]["id"];
export type Optic = (typeof OPTICS)[number]["id"];
export type Weapon = (typeof WEAPONS)[number]["id"];
export type Background = (typeof BACKGROUNDS)[number]["id"];
export type Clothing = (typeof CLOTHES)[number]["id"];
export type KitItem = (typeof KITS)[number]["id"];
export type VisibleHair = Exclude<Hair, "random">;

export type Loadout = {
  gender: Gender;
  framing: Framing;
  pose: Pose;
  mask: Mask;
  hair: Hair;
  pattern: Pattern;
  optic: Optic;
  weapon: Weapon;
  background: Background;
  clothing: Clothing;
  hairColor: HairColor;
  eyeColor: EyeColor;
  skin: Skin;
  head: Head;
  bottoms: Bottoms;
  kit: KitItem[];
};

export type ForgeInput = Loadout & { detail: string };

export const HOUSE_LOADOUT: Loadout = {
  gender: "male",
  framing: "parade",
  mask: "drip",
  hair: "covered",
  pattern: "multicam",
  optic: "dual-up",
  weapon: "carbine-ready",
  background: "green",
  clothing: "uniform",
  hairColor: "brown",
  eyeColor: "brown",
  skin: "fair",
  head: "helmet",
  bottoms: "shorts",
  pose: "stand",
  kit: ["knees", "radio", "holster", "gloves"],
};

export const PRESETS: { id: string; label: string; note: string; loadout: Loadout }[] = [
  {
    id: "parade",
    label: "Parade",
    note: "Full figure, low ready",
    loadout: HOUSE_LOADOUT,
  },
  {
    id: "bust",
    label: "Portrait",
    note: "Helmet and face, tight",
    loadout: {
      gender: "male",
      framing: "bust",
      mask: "drip",
      hair: "covered",
      pattern: "multicam",
      optic: "dual-up",
      weapon: "hands",
      background: "green",
      clothing: "uniform",
      hairColor: "brown",
      eyeColor: "brown",
      skin: "fair",
      head: "helmet",
      bottoms: "shorts",
      pose: "stand",
      kit: ["radio", "gloves"],
    },
  },
  {
    id: "contact",
    label: "Contact",
    note: "Stepping in, on the trigger",
    loadout: {
      gender: "male",
      framing: "contact",
      mask: "angry",
      hair: "covered",
      pattern: "multicam",
      optic: "dual-up",
      weapon: "carbine-aim",
      background: "green",
      clothing: "uniform",
      hairColor: "brown",
      eyeColor: "brown",
      skin: "fair",
      head: "helmet",
      bottoms: "shorts",
      pose: "stand",
      kit: ["knees", "holster", "gloves", "smoke"],
    },
  },
];

const CALLSIGNS = [
  "HOLLOW",
  "DRIFT",
  "VESPER",
  "KESTREL",
  "MOTH",
  "LANTERN",
  "RAVEN",
  "STATIC",
  "NORTH",
  "CIPHER",
  "WILLOW",
  "ASH",
  "MARROW",
  "QUIET",
  "BRAMBLE",
  "PETREL",
  "SABLE",
  "FEN",
  "HARROW",
  "OSPREY",
  "BIRCH",
  "CINDER",
  "MOOR",
  "THORN",
  "GLASS",
];

const VISIBLE_HAIRS: VisibleHair[] = ["pony", "bun", "loose", "braid", "crop"];

const GENDER_LINE: Record<Gender, string> = {
  male: "Adult male operator. Broader shoulders and a straighter torso, fully dressed in the tactical uniform, plate carrier, and boots.",
  female:
    "Adult woman with a strongly curvy figure: full bust, small waist, wide hips, thick thighs, and a rounded seat. The silhouette has to read clearly. Fully clothed. Same bold cartoon outlines, flat color, not a photograph.",
};

const GEAR_FIT =
  "Smaller gear than the reference. A short chest rig or cropped carrier that ends at the waist, slim pouches, and straps that follow the body. Do not hide the bust, waist, hips, or thighs under a bulky carrier.";

const CLOTHES_LINE: Record<Clothing, string> = {
  uniform:
    "Fitted camouflage shirt and pants, cut close to the waist, hips, and thighs. Not baggy. Short plate carrier ending above the belt.",
  tank:
    "Fitted tank top and short fitted shorts. Midriff, hips, and thighs visible. A small chest rig only, not a full uniform. Still fully clothed.",
  crop:
    "Short crop top and short fitted shorts. Waist and hips visible. Small chest rig, not a bulky carrier. Still fully clothed.",
  tee:
    "Tight short-sleeve t-shirt and short fitted shorts. The shirt follows the bust and waist. Small chest rig. Still fully clothed.",
  rig:
    "Small open chest rig over a tank top and short shorts, so the waist, hips, and thighs stay visible. Still fully clothed.",
  openrig:
    "No shirt under a chest rig. The rig's front panel and pouches cover the chest. Shoulders, arms, and midriff are bare. Covered, not nude.",
  plate:
    "A coyote plate carrier worn over a fitted tank top. The tank shows at the shoulders, neckline, and under the carrier hem. Still fully clothed.",
  sport:
    "An open coyote plate carrier over an athletic sports bra. The sports bra covers the chest and shows at the shoulders, neckline, and under the carrier. Midriff bare. Still covered.",
  sportcamo:
    "An open coyote plate carrier over a camouflage athletic sports top. The top covers the chest and shows at the shoulders and under the carrier. Midriff bare. Still covered.",
  croptop:
    "An athletic crop top under a coyote plate carrier. The crop shows at the shoulders and below the carrier. Midriff visible. Still fully clothed.",
  camotank:
    "A coyote plate carrier over a camouflage tank top. The camo tank shows at the shoulders, neckline, and under the carrier hem. Still fully clothed.",
  open:
    "No shirt under a coyote plate carrier. The carrier covers the chest. Shoulders, arms, and midriff are bare. Short fitted shorts and boots stay on. Covered, not nude.",
};

const FRAMING_LINE: Record<Framing, string> = {
  parade:
    "Full-body standing figure centered in frame, both boots visible, facing the camera in a relaxed ready stance.",
  bust: "Tight portrait from the chest up, helmet near the top edge, facing the camera.",
  contact:
    "Dynamic three-quarter action, weight stepping forward, body angled toward screen right.",
};

const CAMERA_LINE: Record<Framing, string> = {
  parade: "Full body in frame.",
  bust: "Tight portrait. If the pose is low, keep the head and weapon large in frame.",
  contact: "Three-quarter view, body angled toward screen right.",
};

const POSE_LINE: Record<Pose, string> = {
  stand: "Standing, weight even.",
  prone:
    "Prone. Lying flat on the stomach, elbows planted, legs stretched back, weapon shouldered and pointed forward.",
  crouch: "Crouched low on both feet, knees bent, torso upright.",
  ready: "Ready. Weapon up and aimed toward screen right, cheek to the stock.",
  squat: "Side squat. A deep squat seen from the side, one knee out, weight low.",
};

const MASK_LINE: Record<Mask, string> = {
  drip: "White skull mask with huge round black eye sockets, a black triangular nose, a black mouth, and long uneven white paint drips running off the chin.",
  angry:
    "White skull mask with narrowed, angled black eye sockets in an angry glare, a black triangular nose, and short white paint drips.",
  cracked:
    "White skull mask with a fine crack across the brow and through one eye socket, huge black sockets, and white paint drips.",
  visor:
    "Skull painted on a black balaclava under a clear visor rim, huge black eye sockets, white paint drips below the visor.",
  ghost:
    "Smoother white ghost-skull mask, large black eye sockets, small nose, soft white drip edges along the jaw.",
  balaclava: "Plain black balaclava. Only the eyes show through a narrow opening. No skull paint.",
  wrap: "Tan shemagh wrapped over the nose and mouth. Eyes visible. No skull paint.",
  respirator: "Black full-face respirator with two round side filters. Dark eye lenses.",
  half: "Human eyes and brow, with white skull paint and drips covering the mouth and jaw.",
  bare: "No mask. Cartoon adult face with clean black outlines, a serious expression, and eyes toward the camera.",
};

const HAIR_LINE: Record<VisibleHair, string> = {
  covered: "No hair visible. It is fully tucked under the headwear.",
  pony: "A high ponytail comes out from under the back of the headwear, with a few loose strands.",
  bun: "A tight bun sits at the back of the headwear.",
  loose: "Long hair falls past the shoulders from under the headwear.",
  braid: "One braid hangs over the shoulder from under the headwear.",
  crop: "Short cropped hair shows at the temples and nape.",
};

const HAIR_COLOR_LINE: Record<HairColor, string> = {
  black: "black",
  brown: "dark brown",
  blonde: "blonde",
  red: "red",
  pink: "hot pink",
  white: "white",
};

const EYE_COLOR_LINE: Record<EyeColor, string> = {
  brown: "brown",
  blue: "blue",
  green: "green",
  gray: "gray",
  hazel: "hazel",
};

const EYES_HIDDEN = new Set<Mask>(["drip", "angry", "cracked", "visor", "ghost", "respirator"]);

const SKIN_LINE: Record<Skin, string> = {
  fair: "fair",
  tan: "tan",
  olive: "olive",
  brown: "brown",
  deep: "deep brown",
};

const HEAD_LINE: Record<Head, string> = {
  helmet: "Oversized camouflage helmet, the same mascot helmet as the reference.",
  boonie: "A camouflage boonie hat with a wide brim. No helmet.",
  cap: "A camouflage baseball cap. No helmet.",
  beanie: "A knit watch cap. No helmet.",
  headset: "No hat and no helmet. Only the tan headset with a boom microphone.",
  band: "A camouflage headband. No helmet.",
};

const BOTTOMS_LINE: Record<Bottoms, string> = {
  shorts: "Short fitted shorts. Not pants and not underwear.",
  shorter: "Very short fitted shorts, high on the thigh. Still shorts, not underwear.",
  highcut: "High-cut athletic shorts, cut high on the hip. Still shorts, not underwear.",
  camocut: "High-cut camouflage shorts, cut high on the hip. Still shorts, not underwear.",
  highleg: "High-leg athletic shorts with a higher leg opening. Still shorts that cover, not underwear.",
  pants: "Fitted tactical pants instead of shorts.",
};

const PATTERN_LINE: Record<Pattern, string> = {
  multicam:
    "Classic multicam blotches of tan, brown, and olive on the helmet, uniform, and pouches. Coyote tan plate carrier and boots.",
  woodland:
    "Woodland green and brown camouflage on the helmet and uniform. Coyote tan plate carrier, pouches, and boots.",
  desert:
    "Three-color desert camouflage, tan and pale brown, on the helmet and uniform. Coyote plate carrier and boots.",
  ranger:
    "Solid ranger green uniform and helmet cover. Coyote tan plate carrier, pouches, and boots.",
  black:
    "Black and dark gray camouflage on the helmet and uniform. Coyote tan plate carrier, pouches, and boots.",
  winter:
    "White and light gray winter camouflage on the helmet and uniform. Coyote tan plate carrier and boots.",
};

const OPTIC_LINE: Record<Optic, string> = {
  "dual-up": "Dual-tube black night-vision goggles flipped up on the helmet mount.",
  "dual-down": "Dual-tube black night-vision goggles flipped down over the eyes, dark lenses.",
  quad: "Four-tube panoramic black night vision mounted on the helmet, tubes flipped up.",
  bare: "No night vision. Camo helmet with side rails only.",
};

const WEAPON_LINE: Record<Weapon, string> = {
  "carbine-ready":
    "A tan carbine held across the torso at low ready, black magazine, muzzle angled down.",
  "carbine-aim":
    "A tan carbine shouldered and aimed toward screen right, black magazine, a small puff of muzzle smoke.",
  suppressed:
    "A tan carbine with a long black suppressor, held at low ready, black magazine.",
  marksman:
    "A longer tan marksman rifle with a scope, held across the body, black magazine.",
  sniper:
    "A long tan sniper rifle with a large scope and a folded bipod. Not a short carbine.",
  smg: "A compact tan submachine gun held across the chest.",
  mg: "A tan belt-fed machine gun held at the hip, belt visible.",
  shotgun: "A tan tactical shotgun held at low ready across the body.",
  bow: "A camouflage compound bow in one hand, a quiver of arrows on the hip. No firearm.",
  sidearm: "A tan pistol in a compressed ready, the other gloved hand near the chest. No long gun.",
  blade: "A fixed black blade held low in one hand. No firearm.",
  hands: "Empty gloved hands. No weapon in the picture.",
};

const BACKGROUND_LINE: Record<Background, string> = {
  green: "Keep a flat solid chroma-green studio background with no scenery.",
  forest: "Replace the green screen with a daylight forest of trees and soft ground shadow. The operator stays fully lit.",
  desert: "Replace the green screen with a bright desert of sand and a pale sky. The operator stays fully lit.",
  night: "Replace the green screen with a dark night scene, faint moonlight, no green left.",
  urban: "Replace the green screen with a gray concrete alley, overcast light, no green left.",
  snow: "Replace the green screen with an overcast snow field and pale sky, no green left.",
  hangar: "Replace the green screen with a dim indoor armory, gray concrete and a dark wall.",
  dusk: "Replace the green screen with an open field at orange dusk. The operator stays readable.",
};

const KIT_LINE: Record<KitItem, string> = {
  knees: "tan hard-shell knee pads",
  radio: "a radio with a short antenna on the plate carrier",
  holster: "a drop-leg holster with a pistol",
  pack: "a compact tan backpack",
  gloves: "tan tactical gloves",
  smoke: "a small white smoke wisp near the shoulder",
};

function ids<T extends string>(rows: readonly { id: T }[]): T[] {
  return rows.map((row) => row.id);
}

export const GENDER_IDS = ids(GENDERS);
export const FRAMING_IDS = ids(FRAMINGS);
export const POSE_IDS = ids(POSES);
export const MASK_IDS = ids(MASKS);
export const HAIR_IDS = ids(HAIRS);
export const HAIR_COLOR_IDS = ids(HAIR_COLORS);
export const EYE_COLOR_IDS = ids(EYE_COLORS);
export const SKIN_IDS = ids(SKINS);
export const HEAD_IDS = ids(HEADS);
export const BOTTOMS_IDS = ids(BOTTOMS);
export const PATTERN_IDS = ids(PATTERNS);
export const OPTIC_IDS = ids(OPTICS);
export const WEAPON_IDS = ids(WEAPONS);
export const BACKGROUND_IDS = ids(BACKGROUNDS);
export const CLOTHES_IDS = ids(CLOTHES);
export const KIT_IDS = ids(KITS);

function isOneOf<T extends string>(value: unknown, options: readonly T[]): value is T {
  return typeof value === "string" && (options as readonly string[]).includes(value);
}

export function parseForgeInput(input: unknown): ForgeInput | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as Record<string, unknown>;
  const gender: Gender = isOneOf(raw.gender, GENDER_IDS) ? raw.gender : "male";
  const hair: Hair = isOneOf(raw.hair, HAIR_IDS) ? raw.hair : "covered";
  const background: Background = isOneOf(raw.background, BACKGROUND_IDS) ? raw.background : "green";
  const clothing: Clothing = isOneOf(raw.clothing, CLOTHES_IDS) ? raw.clothing : "uniform";
  const hairColor: HairColor = isOneOf(raw.hairColor, HAIR_COLOR_IDS) ? raw.hairColor : "brown";
  const eyeColor: EyeColor = isOneOf(raw.eyeColor, EYE_COLOR_IDS) ? raw.eyeColor : "brown";
  const skin: Skin = isOneOf(raw.skin, SKIN_IDS) ? raw.skin : "fair";
  const head: Head = isOneOf(raw.head, HEAD_IDS) ? raw.head : "helmet";
  const bottoms: Bottoms = isOneOf(raw.bottoms, BOTTOMS_IDS) ? raw.bottoms : "shorts";
  const pose: Pose = isOneOf(raw.pose, POSE_IDS) ? raw.pose : "stand";
  if (!isOneOf(raw.framing, FRAMING_IDS)) return null;
  if (!isOneOf(raw.mask, MASK_IDS)) return null;
  if (!isOneOf(raw.pattern, PATTERN_IDS)) return null;
  if (!isOneOf(raw.optic, OPTIC_IDS)) return null;
  if (!isOneOf(raw.weapon, WEAPON_IDS)) return null;
  if (!Array.isArray(raw.kit) || raw.kit.length > KITS.length) return null;
  const kit: KitItem[] = [];
  for (const item of raw.kit) {
    if (!isOneOf(item, KIT_IDS)) return null;
    if (!kit.includes(item)) kit.push(item);
  }
  const detail =
    typeof raw.detail === "string"
      ? raw.detail.replace(/[\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 140)
      : "";
  return {
    gender,
    framing: raw.framing,
    pose,
    mask: raw.mask,
    hair,
    pattern: raw.pattern,
    optic: raw.optic,
    weapon: raw.weapon,
    background,
    clothing,
    hairColor,
    eyeColor,
    skin,
    head,
    bottoms,
    kit,
    detail,
  };
}

export function resolveHair(hair: Hair): VisibleHair {
  if (hair !== "random") return hair;
  const index = Math.floor(Math.random() * VISIBLE_HAIRS.length);
  return VISIBLE_HAIRS[index] ?? "pony";
}

export function buildPrompt(input: ForgeInput, hair: VisibleHair): string {
  const female = input.gender === "female";
  const kit =
    input.kit.length > 0
      ? input.kit.map((item) => KIT_LINE[item]).join(", ")
      : female
        ? "no extra kit beyond the small chest rig and boots"
        : "no extra kit beyond the plate carrier and boots";
  const lines = [
    "Keep this exact illustration style: bold uniform black outlines, flat color fills, clean vector cartoon, tan headset with a boom microphone, tactical gear drawn like a mascot operator, flat even light. No text, no letters, no watermark, no interface chrome, no photograph, no extra people.",
    "Redraw the operator with these changes:",
    `Build: ${GENDER_LINE[input.gender]}`,
    `Skin: Visible skin on the neck, hands, and any bare arms or legs is ${SKIN_LINE[input.skin]}.`,
    `Framing: ${input.pose === "stand" ? FRAMING_LINE[input.framing] : CAMERA_LINE[input.framing]}`,
    `Pose: ${POSE_LINE[input.pose]}${input.pose === "stand" ? "" : " The pose decides the body and how the weapon is held. Do not leave them standing if the pose is prone, crouched, ready, or squatting."}`,
    `Face: ${MASK_LINE[input.mask]}`,
    EYES_HIDDEN.has(input.mask)
      ? "Eyes: Covered by the face, so no eye color shows."
      : `Eyes: ${EYE_COLOR_LINE[input.eyeColor]} eyes.`,
    `Hair: ${HAIR_LINE[hair]} Hair color is ${HAIR_COLOR_LINE[input.hairColor]}.`,
    `Head: ${HEAD_LINE[input.head]}`,
    `Camouflage: ${PATTERN_LINE[input.pattern]}`,
    input.head === "helmet"
      ? `Helmet: ${OPTIC_LINE[input.optic]}`
      : "Helmet: Do not draw a helmet or night vision.",
    `Weapon: ${WEAPON_LINE[input.weapon]}`,
    `Background: ${BACKGROUND_LINE[input.background]}`,
  ];
  if (female) {
    lines.push(
      input.clothing === "plate" ||
      input.clothing === "sport" ||
      input.clothing === "sportcamo" ||
      input.clothing === "croptop" ||
      input.clothing === "camotank"
        ? "Gear: A plate carrier fitted to her torso, with a few pouches. The top underneath stays visible at the shoulders and below the hem."
        : input.clothing === "open"
          ? "Gear: A plate carrier worn with no shirt under it, fitted so it covers the chest, with a few pouches. Shoulders and midriff stay bare. Shorts stay on."
          : input.clothing === "openrig"
            ? "Gear: A chest rig with no shirt under it. The front panel and pouches cover the chest. Shoulders and midriff stay bare."
            : `Gear: ${GEAR_FIT}`,
    );
    lines.push(`Clothes: ${CLOTHES_LINE[input.clothing]}`);
    if (input.clothing !== "uniform") {
      lines.push("Do not put her back in a baggy full uniform. Camouflage colors apply to the headwear.");
    }
    lines.push(`Bottoms: ${BOTTOMS_LINE[input.bottoms]} This replaces any shorts or pants mentioned above.`);
  }
  lines.push(`Kit: ${kit}.`);
  if (input.detail) {
    lines.push(`Additional wardrobe note, only if it fits the same cartoon operator: ${input.detail}.`);
  }
  return lines.join("\n");
}

export function aspectFor(framing: Framing): "2:3" | "1:1" | "3:4" {
  if (framing === "bust") return "1:1";
  if (framing === "contact") return "3:4";
  return "2:3";
}

export function sameLoadout(a: Loadout, b: Loadout): boolean {
  if (
    a.gender !== b.gender ||
    a.framing !== b.framing ||
    (a.pose ?? "stand") !== (b.pose ?? "stand") ||
    a.mask !== b.mask ||
    (a.hair ?? "covered") !== (b.hair ?? "covered") ||
    a.pattern !== b.pattern ||
    a.optic !== b.optic ||
    a.weapon !== b.weapon ||
    (a.background ?? "green") !== (b.background ?? "green") ||
    (a.clothing ?? "uniform") !== (b.clothing ?? "uniform") ||
    (a.hairColor ?? "brown") !== (b.hairColor ?? "brown") ||
    (a.eyeColor ?? "brown") !== (b.eyeColor ?? "brown") ||
    (a.skin ?? "fair") !== (b.skin ?? "fair") ||
    (a.head ?? "helmet") !== (b.head ?? "helmet") ||
    (a.bottoms ?? "shorts") !== (b.bottoms ?? "shorts") ||
    a.kit.length !== b.kit.length
  ) {
    return false;
  }
  const left = [...a.kit].sort();
  const right = [...b.kit].sort();
  return left.every((item, index) => item === right[index]);
}

export function randomCallsign(current?: string): string {
  const pool = CALLSIGNS.filter((name) => name !== current);
  const index = Math.floor(Math.random() * pool.length);
  return pool[index] ?? "HOLLOW";
}

export function randomLoadout(): Loadout {
  const pick = <T extends string>(options: readonly T[]) =>
    options[Math.floor(Math.random() * options.length)] as T;
  const kitCount = 2 + Math.floor(Math.random() * 3);
  const bag = [...KIT_IDS];
  const kit: KitItem[] = [];
  while (kit.length < kitCount && bag.length) {
    const index = Math.floor(Math.random() * bag.length);
    const [item] = bag.splice(index, 1);
    if (item) kit.push(item);
  }
  const gender = pick(GENDER_IDS);
  return {
    gender,
    framing: pick(FRAMING_IDS),
    pose: pick(POSE_IDS),
    mask: pick(MASK_IDS),
    hair: pick(HAIR_IDS),
    pattern: pick(PATTERN_IDS),
    optic: pick(OPTIC_IDS),
    weapon: pick(WEAPON_IDS),
    background: pick(BACKGROUND_IDS),
    clothing: gender === "female" ? pick(CLOTHES_IDS) : "uniform",
    hairColor: pick(HAIR_COLOR_IDS),
    eyeColor: pick(EYE_COLOR_IDS),
    skin: pick(SKIN_IDS),
    head: pick(HEAD_IDS),
    bottoms: pick(BOTTOMS_IDS),
    kit,
  };
}

export function sanitizeCallsign(value: string): string {
  return value
    .toUpperCase()
    .replace(/[^A-Z0-9 -]/g, "")
    .slice(0, 16);
}
