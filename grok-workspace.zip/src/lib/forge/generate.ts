import { createServerFn } from "@tanstack/react-start";
import { aspectFor, buildPrompt, parseForgeInput, resolveHair, type Framing } from "@/lib/forge/loadout";

type ImageItem = { b64_json?: string; url?: string; mime_type?: string };

const COOLDOWN_MS = 4000;
let lastStarted = 0;

function failure(status: number, raw: string): string {
  let msg = "";
  try {
    const parsed = JSON.parse(raw) as { error?: { message?: string } | string };
    if (typeof parsed.error === "string") msg = parsed.error;
    else if (parsed.error && typeof parsed.error.message === "string") msg = parsed.error.message;
  } catch {
    msg = "";
  }
  if (/policy|moderat|safety|violate/i.test(msg)) {
    return "That kit was refused. Change the note and forge again.";
  }
  if (status === 429) return "The forge is busy. Wait a moment and try again.";
  if (status === 401 || status === 403) return "Image forging isn’t available right now.";
  return "The forge didn’t answer. Try again.";
}

async function toDataUrl(item: ImageItem, apiKey: string): Promise<string | null> {
  if (item.b64_json) {
    const mime = item.mime_type || "image/jpeg";
    return `data:${mime};base64,${item.b64_json}`;
  }
  if (!item.url) return null;
  const image = await fetch(item.url, {
    headers: { Authorization: `Bearer ${apiKey}` },
    signal: AbortSignal.timeout(30_000),
  });
  if (!image.ok) return null;
  const mime = image.headers.get("content-type") || "image/jpeg";
  const bytes = Buffer.from(await image.arrayBuffer());
  return `data:${mime};base64,${bytes.toString("base64")}`;
}

export const forgeStatus = createServerFn({ method: "GET" }).handler(async () => {
  return { ready: Boolean(process.env.XAI_API_KEY) };
});

export const forgeOperator = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }) => {
    const spec = parseForgeInput(data);
    if (!spec) return { ok: false as const, error: "That kit isn’t one of the plates." };

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Image forging isn’t available right now." };

    const now = Date.now();
    if (now - lastStarted < COOLDOWN_MS) {
      return { ok: false as const, error: "Give the forge a second." };
    }
    lastStarted = now;

    const { refData } = await import("@/lib/forge/ref-data");
    const framing = spec.framing as Framing;
    const reference = refData[framing];
    const hair = resolveHair(spec.hair);

    let response: Response;
    try {
      response = await fetch("https://api.x.ai/v1/images/edits", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        signal: AbortSignal.timeout(70_000),
        body: JSON.stringify({
          model: "grok-imagine-image-2.0",
          prompt: buildPrompt(spec, hair),
          image: { url: reference, type: "image_url" },
          response_format: "b64_json",
          aspect_ratio: aspectFor(framing),
          resolution: "1k",
          quality: "medium",
        }),
      });
    } catch {
      return { ok: false as const, error: "The forge didn’t answer. Try again." };
    }

    if (!response.ok) {
      const raw = await response.text();
      return { ok: false as const, error: failure(response.status, raw) };
    }

    const body = (await response.json()) as { data?: ImageItem[] };
    const item = body.data?.[0];
    if (!item) return { ok: false as const, error: "The forge came back empty. Try again." };

    try {
      const image = await toDataUrl(item, apiKey);
      if (!image) return { ok: false as const, error: "The forge came back empty. Try again." };
      return { ok: true as const, image, hair };
    } catch {
      return { ok: false as const, error: "The forge didn’t answer. Try again." };
    }
  });
